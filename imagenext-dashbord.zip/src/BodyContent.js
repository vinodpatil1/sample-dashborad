import React from 'react'

const BodyContent = () => {
  return (
     <>
      <section className='body-centent'>
      <div className="row pt-3 pt-md-5">
          <div className="col-12 col-md-7">
                <div className="card mb-3">
                    <div className="card-body">
                    <div className="card-header mb-3">
                    <span className='card-title'>Recently Booked Tickets</span>
                    </div>
                     <p>3 tikets for movie 123 booked by rajesh mehata</p>
                     <p>3 tikets for movie 123 booked by rajesh mehata</p>
                     <p>3 tikets for movie 123 booked by rajesh mehata</p>
                     <p>3 tikets for movie 123 booked by rajesh mehata</p>
                    </div>
                </div>
          </div>
          <div className="col-12 col-md-5">
             <div className="card">
             <div className="card-body">
             <div className="card-header mb-3">
                    <span className='card-title'>Discription</span>
                    </div>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos voluptatum natus illum earum, accusamus, aut ullam consequatur nam quis eius tempora molestiae, maxime explicabo odio magnam a dolores fugiat quam!</p>
             </div>
             </div>
          </div>
        </div>
      </section>
     </>
  )
}

export default BodyContent;
