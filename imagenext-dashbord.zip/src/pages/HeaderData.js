const HeaderData = [
    {
        id: 0,
        title:"Welcome",
      
    },
    {
        id: 1,
        title: "Events",
    },
    {
        id: 2,
        title: "Movies",
    },
    {
        id: 3,
        title: "Taks",
    },
    {
        id: 4,
        title: "Teams",
    },
    {
        id: 5,
        title: "Documentation",
    },
    

  ];




  export default HeaderData;