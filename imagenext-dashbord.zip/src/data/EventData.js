
import ev1 from "../images/ev1.jpg";  
import ev2 from "../images/ev2.jpg";  
import ev3 from "../images/ev3.jpg";  
import ev4 from "../images/ev4.jpg";  


const curentDate = new Date();



const EventData = [
    {
        id: 1,
        imgscr:ev1,
        title: "Night Party",
        date:"30/6/2023",
        
    },
    {
        id: 2,
        imgscr:ev2,
        title: "Together Party",
        date:"30/6/2023",
   },
   {
        id: 3,
        imgscr:ev3,
        title: "Marrige Party",
        date:"30/6/2023",
   },
    {
        id: 4,
        imgscr:ev4,
        title: "Hotel Event",
        date:"30/6/2023",
    }


  ];




  export default EventData;