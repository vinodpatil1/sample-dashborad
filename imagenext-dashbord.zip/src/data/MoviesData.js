
import Sholay from "../images/sholay.png";  
import Gadar from "../images/gadar.png";  
import dhom3 from "../images/dhom3.png";  
import ghayal from "../images/ghayal.png";  
import rockstar from "../images/rock-star.png";  
import dilwale from "../images/dilwale.png";  


const MoviesData = [
    {
        id: 1,
        imgscr:Sholay,
        mvname: "Sholay",
        link:"Book Now",
        
    },
    {
        id: 2,
        imgscr:Gadar,
        mvname: "Gadar",
        link:"Book Now",
   },
   {
        id: 3,
        imgscr:dhom3,
        mvname: "Dhom3",
        link:"Book Now",
   },
    {
        id: 4,
        imgscr:ghayal,
        mvname: "Ghayal",
        link:"Book Now",
    },
    {
        id: 5,
        imgscr:rockstar,
        mvname: "Rockstar",
        link:"Book Now",
    },
    {
        id: 6,
        imgscr:dilwale,
        mvname: "Dilwale",
        link:"Book Now",
    }

  ];




  export default MoviesData;