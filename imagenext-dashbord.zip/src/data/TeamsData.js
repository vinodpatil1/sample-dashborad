
const TeamsData = [
    {
        id: 1,
        imgscr:"https://picsum.photos/id/237/500/300",
        title: "Apolline  Cathenna",
        content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        link:"Share",
        
    },
    {
        id: 2,
        imgscr:"https://picsum.photos/seed/picsum/500/300",
        title: "Peppi Malia ",
        content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        link:"Share",
   },
   {
        id: 3,
        imgscr:"https://picsum.photos/seed/picsum/500/300",
        title: "Hrisovalantis ",
        content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        link:"Share",
   },
    {
        id: 4,
        imgscr:"https://picsum.photos/500/300/?blur",
        title: "Jack Helson ",
        content: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s",
        link:"Share",
    }

  ];




  export default TeamsData;