 
 
 
const CardData = [
    {
        id: 1,
        title: "Shows booking",
        content: "2304",
        ftext : "2650",
    },
    {
        id: 2,
        title: "Event booking",
        content: "438",
        ftext : "349",
   },
   {
        id: 3,
        title: "Shows ended",
        content: "1876",
        ftext : "2283",
   },
    {
        id: 3,
        title: "Upcoming Shows",
        content: "3475",
        ftext : "3475",
    }

  ];




  export default CardData;